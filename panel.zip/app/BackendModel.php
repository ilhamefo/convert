<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BackendModel extends Model
{
    //
}
