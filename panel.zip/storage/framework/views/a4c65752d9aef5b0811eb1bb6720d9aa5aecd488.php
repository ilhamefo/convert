<?php $__env->startSection('title', 'Admin'); ?>
<?php $__env->startSection('content'); ?>

<div class="header">
    <div class="container header-container">
        <div class="col-lg-3 header-img-section">
        <img src="<?php echo e(asset('')); ?>assets/images/blog-card-1.png">
        </div>
        <div class="col-lg-8 offset-lg-1 header-title-section">
        <p class="header-subtitle"><?php echo e($data['company'][0]->nama_perusahaan); ?></p>
            <h1 class="header-title">Terima Kasih</h1>
            <p class="header-title-text">Sudah Menggunakan Layanan Kami. Berikut Adalah Detail Order Anda. Untuk Melanjutkan Order, Silahkan Tekan Tombol Lanjutkan dibawah.</p>
            <p>
                <?php echo e($data['strip']); ?> <br>

                ID Order : <?php echo e($data['order'][0]->id_order); ?> <hr>
                Nama : <?php echo e($data['order'][0]->nama); ?> <hr>
                E-mail : <?php echo e($data['order'][0]->email); ?><hr>
                Nama Provider : <?php echo e($data['order'][0]->nama_provider); ?><hr>
                Nominal Pulsa : <?php echo e($data['order'][0]->nominal_pulsa); ?><hr>
                Nomor Pengirim : <?php echo e($data['order'][0]->nomor_pengirim); ?><hr>
                Bank : <?php echo e($data['order'][0]->nama_bank); ?><hr>
                Atas Nama :<?php echo e($data['order'][0]->atas_nama); ?><hr>
                Nomor Rekening : <?php echo e($data['order'][0]->nomor_rekening); ?><hr>
                <?php echo e($data['strip']); ?> <br>
                Yang akan dapatkan : <?php echo e(number_format($data['result'], 2, ",", ".")); ?> <br>
                <?php echo e($data['strip']); ?><br>
            </p>
            <div class="learn-more-btn-section">
            <a class="nav-link learn-more-btn btn-invert" href="https://wa.me/6287889655707?text=<?php echo e(urlencode($data['text'])); ?>" >Lanjutkan.</a>
            </div>
        </div>
    </div>
</div>

<br><br>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\laravel-convert\backend\laravel\panel\resources\views/order.blade.php ENDPATH**/ ?>