<!DOCTYPE html>
<html lang="en">

<head>
    <title>Login Admin</title>

    <link href="<?php echo e(asset("")); ?>lib/font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="<?php echo e(asset("")); ?>lib/Ionicons/css/ionicons.css" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset("")); ?>css/bracket.css">
</head>

<body>

    <div class="d-flex align-items-center justify-content-center bg-br-primary ht-100v">

        <div class="login-wrapper wd-300 wd-xs-350 pd-25 pd-xs-40 bg-white rounded shadow-base">
            <div class="signin-logo tx-center tx-28 tx-bold tx-inverse"><span class="tx-normal">[</span> Login Admin <span
                    class="tx-normal">]</span></div>
            <div class="tx-center mg-b-60">Login Admin..</div>
            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <input type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter your Email" value="<?php echo e(old('email')); ?>" name="email">
                </div>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-group">
                    <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        placeholder="Enter your password" name="password" required autocomplete="current-password">
                    <a href="#" class="tx-info tx-12 d-block mg-t-10">Forgot password?</a>
                </div>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <button type="submit" class="btn btn-info btn-block">Sign In</button>
            </form>

        </div>
    </div>

    <script src="<?php echo e(asset("")); ?>lib/jquery/jquery.js"></script>
    <script src="<?php echo e(asset("")); ?>lib/popper.js/popper.js"></script>
    <script src="<?php echo e(asset("")); ?>lib/bootstrap/bootstrap.js"></script>

</body>

</html>
<?php /**PATH F:\xampp\htdocs\laravel-convert\backend\laravel\panel\resources\views/auth/login.blade.php ENDPATH**/ ?>